package uz.pdp;

public interface BotConstants {
    String START = "/start";
    String BACK = "Back";
    String NAMOZ_VAQT = "Namoz Vaqtlari";
    String NAMOZ_VAQT_2 = "Namoz vaqtlari";
    String ENG_YAQIN_NAMOZ = "Eng Yaqin Namoz\uD83D\uDCAC";
    String HIJRIY_YIL_XISOB = "Xijriy Yil Xisobi\uD83D\uDCC6";
    String ENG_YAQIN_MASJID = "Eng yaqin Masjidlar\uD83D\uDD4C";
    String QURONI_KARIMDAN_SURAH = "Quroni Karimdan Bazi Suralar\uD83D\uDCD6";
    String TASBEX = "Tasbex\uD83D\uDCFF";
    String SURAH_STARTS = "surahs";
    String SOME_CALLBACK_DATA = "someCallbackData";
    String BOMDOD = "bomdod";
    String PESHIN = "peshin";
    String ASR = "asr";
    String SHOM = "shom";
    String XUFTON = "xufton";
    String NEXT_SURAX = "nextSurax";
    String BACK_SURAX = "backSurax";
    String LSURALAR_STARTS = "lsurahs";
    String ASURALAR_STARTS = "asurahs";
    String TASBEX_CALLBACK = "tasbex";
    String QURAN = "Quran☪️";
    String QURAN_SURALARI = "Quron suralari\uD83E\uDEC0";
    String ALLOH_NAME = "✨Allohning go`zal ismlari";
    String NEXTT = "nextt";
    String BACKK = "backk";
}