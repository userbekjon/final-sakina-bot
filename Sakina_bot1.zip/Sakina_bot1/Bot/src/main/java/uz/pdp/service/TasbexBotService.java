package uz.pdp.service;

import com.fasterxml.jackson.core.type.TypeReference;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.methods.updatingmessages.EditMessageReplyMarkup;
import org.telegram.telegrambots.meta.api.methods.updatingmessages.EditMessageText;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import uz.pdp.model.User;
import uz.pdp.util.BotUtil;
import uz.pdp.util.FilePath;
import uz.pdp.util.JsonUtil;
import uz.pdp.utill.ObjectUtil;

import java.util.List;

public class TasbexBotService {

    public SendMessage getTasbex(long chatId, long userId) {
        User user = ObjectUtil.userService.findUserByUserId(userId);
        SendMessage sendMessage = new SendMessage();
        InlineKeyboardMarkup inlineKeyboardMarkup = createInlineKeyboardMarkup("0" + "\uD83D\uDCFF", "tasbex");
        sendMessage.setChatId(chatId);
        sendMessage.setText("0/33");
        sendMessage.setReplyMarkup(inlineKeyboardMarkup);

        return sendMessage;
    }

    public EditMessageReplyMarkup getUpdateTasbex(long chatId, Integer messageId, long userId) {

        User user = increaseTasbexCount(userId);

        InlineKeyboardMarkup inlineKeyboardMarkup = createInlineKeyboardMarkup(user.getTasbexCount() + "\uD83D\uDCFF", "tasbex");

        EditMessageReplyMarkup editMessageReplyMarkup = new EditMessageReplyMarkup();
        editMessageReplyMarkup.setChatId(chatId);
        editMessageReplyMarkup.setMessageId(messageId);
        editMessageReplyMarkup.setReplyMarkup(inlineKeyboardMarkup);

        return editMessageReplyMarkup;
    }

    private User increaseTasbexCount(long userId) {
        User userr = null;
        List<User> userList = JsonUtil.readGson(FilePath.PATH_USERS, new TypeReference<>() {});
        for (User user : userList) {
            if (user.getUserId() == userId) {
                user.setTasbexCount(user.getTasbexCount() + 1);
                userr = user;
            }
            if (user.getTasbexCount() == 33) {
                user.setTasbexCount(0);
            }
        }
        JsonUtil.writeGson(FilePath.PATH_USERS, userList);
        return userr;
    }

    private InlineKeyboardMarkup createInlineKeyboardMarkup(String buttonText, String callbackData) {
        return BotUtil.inlineKeyboardMarkup(List.of(buttonText), List.of(callbackData), 1);
    }
}
