package uz.pdp;

public interface NomozConstants {
    String bomdodText = "Bomdod nomozi \n Subxi sodiqdan(chin tong otgandan) kun chiqqinchadur.Bomdod nomozini tong yorishganda o'qish mustaxab a'loroqdir.Soat bo'yicha xisoblansa bomdodni kun chiqishdan 40 daqiqacha ilgari o'qish mustaxab vaqtiga muvofiq bo'ladi";
    String peshinText = "Peshin namozi \n Quyosh zavolga (og'ishga) ketganidan so'ng to narsalarni soyasi quyosh tikkaga kelgan payitdagi soyasidan tashqari o'zuzunligiga nisbatan ikki baravar ortguniga qadar.Peshin namozini yoz faslida biroz kechiktirib, qish faslida esa vaqti kirishi bilan o'qish mustaxabdir";
    String asrText = "Asir nomozi \n Xar bir narsani soyasi quyosh tikkga kelgan payitdagi soyasidan tashqari o'ziga nisbatan ikki baravar ortganidan boshlab quyosh botgunchadir Asr nomozini quyosh tig'ini o'zgartirmay,nursiz xolatga kirishidan oldinroq o'qish mustaxabdir";
    String shomText = "Shom nomozi \n Kun botgan payitdan boshlab kunbotar tomondan shafaq (qizg'ish nurlar) g'oyib bo'lgunchadir. Shom nomozini doimo quyosh botishi bilan o'qish mustaxabdir";
    String xuftonText = "Xufton nomozi \n Shafaq batamom yo'qolgandan keyin kiradi.Xufton nomozini kechaning uchidan birining oxirida o'qish afzal va nixoyatda a'lo bo'ladi.Xufton va vitr nomozlarini subxi sodiqqacha o'qisa bo'ladi .Vitr nomozini tun oxirida uyg'onishga qodir bo'lgan kishilar subx oldidan o'qislar, mustaxab amal qilgan bo'ladi";
}
