package uz.pdp.util;

public class FilePath {
    public static final String PATH_KORAN = "file/koran.json";
    public static final String PATH_SURAHS = "file/surahs.json";
    public static final String PATH_SURAHSTATE = "file/surahState.json";
    public static final String PATH_PRAYERTIMES = "file/prayerTimes.json";
    public static final String PATH_USERS = "file/users.json";
    public static final String MESSAGES = "file/resources.properties";
}
