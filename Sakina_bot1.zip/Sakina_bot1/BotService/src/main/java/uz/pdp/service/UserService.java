package uz.pdp.service;

import com.fasterxml.jackson.core.type.TypeReference;
import uz.pdp.model.User;
import uz.pdp.util.FilePath;
import uz.pdp.util.JsonUtil;

import java.util.List;

public class UserService {
    private static List<User> userList = JsonUtil.readGson(FilePath.PATH_USERS, new TypeReference<List<User>>() {});

    public void add(long userId) {
        if (!hasUser(userId)) {
            userList.add(new User(userId, 0));
            JsonUtil.writeGson(FilePath.PATH_USERS ,userList);
        }
    }

    private boolean hasUser(long userId) {
        for (User user : userList) {
            if (user.getUserId() == userId) {
                return true;
            }
        }
        return false;
    }

    public User findUserByUserId(long userId) {
        for (User user : userList) {
            if (user.getUserId() == userId) {
                return user;
            }
        }
        return null;
    }
}
